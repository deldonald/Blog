</main>
<footer class="text-center text-white py-5 mt-5 bg-dark">
    <?= date('d/m/Y') ?> - blog

    <?php unset($_SESSION['msg']); ?>
</footer>

</body>
</html>
