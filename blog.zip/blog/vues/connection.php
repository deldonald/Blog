
    <h2>Connection</h2>
    <form action="index.php" method="post" class="w-50">

        <div class="form-group">
            <label for="">Login</label>
            <input type="text" name="login" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Mot de passz</label>
            <input type="password" name="mdp" class="form-control">
        </div>
        <input type="submit" class="btn-btn-primary" name="connection">
    </form>